import Error from "@/components/Error";

function ErrorPage() {
	return <Error />;
}

export default ErrorPage;
